# currency decimal points lookup
#Yo can check the full list from https://docs.myfatoorah.com/docs/iso-lookups
DECIMAL_POINTS = {
    'KWD': 3,
    'SAR': 2,
    'BHD': 3,
    'AED': 2,
    'QAR': 2,
    'OMR': 3,
    'JOD': 3,
    'EGP': 2,
}