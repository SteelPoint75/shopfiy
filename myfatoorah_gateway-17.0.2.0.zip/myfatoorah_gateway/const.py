# Part of Odoo. See LICENSE file for full copyright and licensing details.

# The codes of the payment methods to activate when Demo is activated.
DEFAULT_PAYMENT_METHODS_CODES = [
    'myfatoorah',
]
